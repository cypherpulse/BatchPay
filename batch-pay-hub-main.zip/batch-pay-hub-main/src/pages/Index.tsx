import { useState, useCallback } from 'react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { CSVUpload } from '@/components/CSVUpload';
import { PreviewTable } from '@/components/PreviewTable';
import { Footer } from '@/components/Footer';
import { calculateTotals, formatAmount } from '@/utils/csv';
import type { ParsedCSV, Recipient } from '@/types/payment';
import { Send, Info } from 'lucide-react';

const Index = () => {
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [errors, setErrors] = useState<string[]>([]);

  const handleParsed = useCallback((data: ParsedCSV) => {
    setRecipients(data.recipients);
    setErrors(data.errors);
  }, []);

  const handleClear = useCallback(() => {
    setRecipients([]);
    setErrors([]);
  }, []);

  const summary = calculateTotals(recipients);
  const validRecipients = recipients.filter(r => r.isValid);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <Hero />
        
        <CSVUpload 
          onParsed={handleParsed} 
          onClear={handleClear}
          hasData={recipients.length > 0}
        />
        
        {recipients.length > 0 && (
          <>
            <PreviewTable recipients={recipients} errors={errors} />
            
            <section className="py-16">
              <div className="container">
                <div className="mx-auto max-w-lg space-y-6">
                  {/* Payment Summary */}
                  <div className="card-base">
                    <h3 className="mb-4 text-lg font-semibold text-foreground">Payment Summary</h3>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Recipients</span>
                        <span className="font-medium text-foreground">{summary.recipientCount}</span>
                      </div>
                      
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Subtotal</span>
                        <span className="font-medium text-foreground">{formatAmount(summary.totalAmount)} ETH</span>
                      </div>
                      
                      <div className="flex justify-between text-sm">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          Protocol Fee (0.5%)
                          <Info className="h-3.5 w-3.5" />
                        </div>
                        <span className="font-medium text-foreground">{formatAmount(summary.fee)} ETH</span>
                      </div>
                      
                      <div className="my-4 h-px bg-border" />
                      
                      <div className="flex justify-between">
                        <span className="font-semibold text-foreground">Total Required</span>
                        <span className="text-lg font-bold text-primary">{formatAmount(summary.totalRequired)} ETH</span>
                      </div>
                    </div>
                  </div>

                  <button
                    disabled={validRecipients.length === 0}
                    className="btn-primary flex w-full items-center justify-center gap-2 py-4 text-base"
                  >
                    <Send className="h-5 w-5" />
                    Execute Batch Payment
                  </button>
                  
                  <p className="text-center text-sm text-muted-foreground">
                    Connect your wallet to execute payment
                  </p>
                </div>
              </div>
            </section>
          </>
        )}
        
        {/* History Section */}
        <section id="history" className="py-16 bg-muted/30">
          <div className="container">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="mb-2 text-2xl font-bold text-foreground md:text-3xl">
                Payment History
              </h2>
              <p className="text-muted-foreground">
                Connect your wallet to view your payment history
              </p>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
