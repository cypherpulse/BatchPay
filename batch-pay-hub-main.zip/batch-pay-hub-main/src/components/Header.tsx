import { Wallet } from 'lucide-react';

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/80 backdrop-blur-lg">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
            <Wallet className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">BatchPay</span>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <a href="#upload" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            Upload
          </a>
          <a href="#preview" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            Preview
          </a>
          <a href="#history" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            History
          </a>
        </nav>

        <button className="btn-primary flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold">
          <Wallet className="h-4 w-4" />
          Connect Wallet
        </button>
      </div>
    </header>
  );
}
